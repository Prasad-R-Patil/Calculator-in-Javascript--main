# Grocery-List Master
Are you hungry? Let’s go some grocery shopping with our grocery list. This is a cool app using which you can keep a list of items you need to buy, you just have to add the items needed. You can also delete the item/items which are not required. 

<a href="https://grocery-list-master.netlify.app/" target="_blank">https://grocery-list-master.netlify.app/</a>

![Preview Image](./Grocery-list_readme.png)